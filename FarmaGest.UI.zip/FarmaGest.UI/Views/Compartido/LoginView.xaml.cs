using System.Windows.Controls;
using FarmaGest.UI.ViewModels.Compartido;

namespace FarmaGest.UI.Views.Compartido;

public partial class LoginView : Page
{
    private readonly LoginViewModel _viewModel;

    public LoginView()
    {
        InitializeComponent();

        _viewModel = new LoginViewModel();
        DataContext = _viewModel;

        // Suscribimos la navegación cuando el ViewModel autoriza el ingreso
        _viewModel.OnLoginExitoso = NavegarSegunPerfil;
    }

    private void TxtPassword_PasswordChanged(object sender, System.Windows.RoutedEventArgs e)
    {
        if (DataContext is LoginViewModel vm)
        {
            vm.Contrasena = TxtPassword.Password;
        }
    }

    private void NavegarSegunPerfil(string perfil)
    {
        switch (perfil)
        {
            case "Administrador":
                NavigationService?.Navigate(new Administrador.AdminHomeView());
                break;
            case "Farmaceutico":
            case "Vendedor":
                NavigationService?.Navigate(new Farmaceutico.VentaView());
                break;
            case "Cliente":
                NavigationService?.Navigate(new Cliente.CatalogoView());
                break;
        }
    }
}